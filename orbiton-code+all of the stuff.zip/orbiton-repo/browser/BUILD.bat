@echo off
title Orbiton Builder

:: Save current directory BEFORE elevation
set "MYDIR=%~dp0"

:: Auto-elevate to Administrator
net session >nul 2>nul
if %errorlevel% neq 0 (
    echo Requesting Administrator rights...
    powershell -Command "Start-Process cmd -ArgumentList '/k cd /d ""%~dp0"" && ""%~f0""' -Verb RunAs -WorkingDirectory ""%~dp0"""
    exit /b
)

:: Make absolutely sure we are in the right folder
cd /d "%MYDIR%"
echo Working directory: %CD%

color 0B
cls
echo.
echo  ==========================================
echo   ORBITON Browser Builder v1.0.0
echo   Running as Administrator - OK
echo  ==========================================
echo.

:: Verify package.json exists here
if not exist "package.json" (
    echo  [ERROR] package.json not found in %CD%
    echo  Make sure BUILD.bat is in the casperuim folder!
    pause & exit /b 1
)
echo  [OK] Found package.json

:: Check Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo  [ERROR] Node.js not found!
    echo  Download: https://nodejs.org
    pause & exit /b 1
)
for /f "tokens=*" %%v in ('node -v') do set NODE_VER=%%v
echo  [OK] Node.js %NODE_VER%
echo.

:: Install
echo  [1/3] Installing dependencies...
echo  ------------------------------------------
call npm install
if %errorlevel% neq 0 (
    echo  [ERROR] npm install failed!
    pause & exit /b 1
)
echo  [OK] Done
echo.

:: Build installer
echo  [2/3] Building installer...
echo  First run takes 5-10 min (downloads Electron)
echo  ------------------------------------------
call npx electron-builder --win nsis --x64 --publish never
if %errorlevel% neq 0 (
    echo  [ERROR] Installer build failed!
    pause & exit /b 1
)
echo  [OK] Installer built
echo.

:: Build portable
echo  [3/3] Building portable...
echo  ------------------------------------------
call npx electron-builder --win portable --x64 --publish never
echo  [OK] Done
echo.

:: Results
echo  ==========================================
echo   Done! Files in dist\:
echo  ==========================================
echo.
for %%f in (dist\*.exe) do echo    %%f
echo.
choice /c YN /m "Open dist folder? (Y/N)"
if %errorlevel%==1 explorer "%MYDIR%dist"
echo.
pause
