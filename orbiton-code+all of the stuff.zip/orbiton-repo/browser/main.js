const { app, BrowserWindow, ipcMain, shell, session } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow;
const settingsPath = path.join(app.getPath('userData'), 'settings.json');
const extensionsPath = path.join(app.getPath('userData'), 'extensions');

function loadSettings() {
  try {
    if (fs.existsSync(settingsPath)) return JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
  } catch {}
  return { homepage: 'orbiton://newtab', searchEngine: 'google', theme: 'dark', bookmarksBar: true };
}

function saveSettings(s) {
  try { fs.writeFileSync(settingsPath, JSON.stringify(s, null, 2)); } catch {}
}

async function loadExtensions() {
  if (!fs.existsSync(extensionsPath)) fs.mkdirSync(extensionsPath, { recursive: true });
  const dirs = fs.readdirSync(extensionsPath);
  for (const dir of dirs) {
    const extPath = path.join(extensionsPath, dir);
    if (fs.statSync(extPath).isDirectory()) {
      try {
        await session.defaultSession.loadExtension(extPath, { allowFileAccess: true });
        console.log('Loaded extension:', dir);
      } catch (e) {
        console.warn('Failed to load extension:', dir, e.message);
      }
    }
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280, height: 800, minWidth: 900, minHeight: 600,
    frame: false, titleBarStyle: 'hidden',
    backgroundColor: '#0d0d12',
    icon: path.join(__dirname, 'assets/icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      webviewTag: true,
      allowRunningInsecureContent: false,
    },
  });
  mainWindow.loadFile('renderer/index.html');
  mainWindow.webContents.session.setPermissionRequestHandler((wc, perm, cb) => cb(true));
}

app.whenReady().then(async () => {
  await loadExtensions();
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.on('window-minimize', () => mainWindow.minimize());
ipcMain.on('window-maximize', () => { mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize(); });
ipcMain.on('window-close', () => mainWindow.close());
ipcMain.handle('get-settings', () => loadSettings());
ipcMain.handle('save-settings', (e, s) => { saveSettings(s); return true; });
ipcMain.handle('get-version', () => app.getVersion());
ipcMain.on('open-external', (e, url) => shell.openExternal(url));
ipcMain.handle('get-extensions-path', () => extensionsPath);
ipcMain.handle('list-extensions', () => {
  try {
    const exts = session.defaultSession.getAllExtensions();
    return Object.values(exts).map(e => ({ id: e.id, name: e.name, version: e.version, path: e.path }));
  } catch { return []; }
});
ipcMain.handle('open-extensions-folder', () => {
  if (!fs.existsSync(extensionsPath)) fs.mkdirSync(extensionsPath, { recursive: true });
  shell.openPath(extensionsPath);
});
