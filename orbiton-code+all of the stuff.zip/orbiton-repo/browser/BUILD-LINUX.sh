#!/bin/bash
# Orbiton Browser Builder — Linux

cd "$(dirname "$0")"

GREEN='\033[0;32m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

echo ""
echo "  =========================================="
echo "   ORBITON Browser Builder v1.0.0 — Linux"
echo "  =========================================="
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}  [ERROR] Node.js not found!${NC}"
    echo "  Install with:"
    echo "    Ubuntu/Debian:  sudo apt install nodejs npm"
    echo "    Arch:           sudo pacman -S nodejs npm"
    echo "    Fedora:         sudo dnf install nodejs"
    exit 1
fi
echo -e "${GREEN}  [OK] Node.js $(node -v)${NC}"
echo -e "${GREEN}  [OK] npm $(npm -v)${NC}"
echo ""

# Install dependencies
echo "  [1/2] Installing dependencies..."
echo "  ------------------------------------------"
npm install
if [ $? -ne 0 ]; then
    echo -e "${RED}  [ERROR] npm install failed!${NC}"
    exit 1
fi
echo -e "${GREEN}  [OK] Done${NC}"
echo ""

# Build
echo "  [2/2] Building for Linux..."
echo "  First run downloads Electron (~200MB), please wait."
echo "  ------------------------------------------"
npx electron-builder --linux AppImage deb --x64 --publish never
if [ $? -ne 0 ]; then
    echo -e "${RED}  [ERROR] Build failed!${NC}"
    echo "  Try: sudo ./BUILD-LINUX.sh"
    exit 1
fi

echo ""
echo "  =========================================="
echo -e "${GREEN}   Done! Files in dist/:${NC}"
echo "  =========================================="
echo ""
ls dist/*.AppImage dist/*.deb 2>/dev/null | while read f; do echo "    $f"; done
echo ""
