# Orbiton Browser

A Chromium-based browser built with Electron.

## Build instructions

### Windows
Double-click BUILD.bat
Output: dist\Orbiton Setup 1.0.0.exe  +  dist\Orbiton-Portable-1.0.0.exe

### Linux
  chmod +x BUILD-LINUX.sh && ./BUILD-LINUX.sh
Output: dist/Orbiton-1.0.0.AppImage  +  dist/orbiton_1.0.0_amd64.deb

### macOS
  chmod +x BUILD-MAC.sh && ./BUILD-MAC.sh
Output: dist/Orbiton-1.0.0.dmg

## Requirements
- Node.js v18 or newer  (https://nodejs.org)
- Internet connection   (downloads Electron ~200MB on first build)

## Run without building
  npm install
  npm start
