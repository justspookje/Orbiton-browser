const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('electronAPI', {
  minimize: () => ipcRenderer.send('window-minimize'),
  maximize: () => ipcRenderer.send('window-maximize'),
  close:    () => ipcRenderer.send('window-close'),
  getSettings:        () => ipcRenderer.invoke('get-settings'),
  saveSettings:       (s) => ipcRenderer.invoke('save-settings', s),
  getVersion:         () => ipcRenderer.invoke('get-version'),
  openExternal:       (url) => ipcRenderer.send('open-external', url),
  getExtensionsPath:  () => ipcRenderer.invoke('get-extensions-path'),
  listExtensions:     () => ipcRenderer.invoke('list-extensions'),
  openExtensionsFolder: () => ipcRenderer.invoke('open-extensions-folder'),
});
