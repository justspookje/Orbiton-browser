#!/bin/bash
# Orbiton Browser Builder — macOS

cd "$(dirname "$0")"

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo "  =========================================="
echo "   ORBITON Browser Builder v1.0.0 — macOS"
echo "  =========================================="
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}  [ERROR] Node.js not found!${NC}"
    echo "  Install with: brew install node"
    echo "  Or download: https://nodejs.org"
    exit 1
fi
echo -e "${GREEN}  [OK] Node.js $(node -v)${NC}"
echo -e "${GREEN}  [OK] npm $(npm -v)${NC}"
echo ""

# Note about signing
echo "  NOTE: Building unsigned .dmg (no Apple Developer account needed)."
echo "  macOS may show a security warning — right-click Orbiton.app -> Open."
echo ""

# Install dependencies
echo "  [1/2] Installing dependencies..."
echo "  ------------------------------------------"
npm install
if [ $? -ne 0 ]; then
    echo -e "${RED}  [ERROR] npm install failed!${NC}"
    exit 1
fi
echo -e "${GREEN}  [OK] Done${NC}"
echo ""

# Build
echo "  [2/2] Building for macOS (x64 + Apple Silicon)..."
echo "  First run downloads Electron (~200MB), please wait."
echo "  ------------------------------------------"
npx electron-builder --mac dmg --publish never
if [ $? -ne 0 ]; then
    echo -e "${RED}  [ERROR] Build failed!${NC}"
    exit 1
fi

echo ""
echo "  =========================================="
echo -e "${GREEN}   Done! Files in dist/:${NC}"
echo "  =========================================="
echo ""
ls dist/*.dmg 2>/dev/null | while read f; do echo "    $f"; done
echo ""
echo "  To open on macOS: right-click Orbiton.dmg -> Open"
echo ""
