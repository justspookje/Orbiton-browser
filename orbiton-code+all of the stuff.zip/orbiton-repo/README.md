# 🪐 Orbiton Browser

A Chromium-based browser built with Electron — free, fast, and cross-platform.

![Version](https://img.shields.io/badge/version-1.0.0-6450ff)
![License](https://img.shields.io/badge/license-MIT-00d4ff)
![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux%20%7C%20Android-brightgreen)

## Download

Head to the [Download page](./download.html) or the [Releases](../../releases) tab.

| Platform | File |
|---|---|
| Windows | `Orbiton Setup 1.0.0.exe` |
| Windows Portable | `Orbiton-Portable-1.0.0.exe` |
| macOS Intel | `Orbiton-1.0.0-x64.dmg` |
| macOS Apple Silicon | `Orbiton-1.0.0-arm64.dmg` |
| Linux | `Orbiton-1.0.0.AppImage` |
| Linux DEB | `orbiton_1.0.0_amd64.deb` |
| Android | `app-debug.apk` (build yourself) |

## Project structure

```
orbiton/
├── browser/          Desktop browser (Electron)
│   ├── BUILD.bat     Windows build script
│   ├── BUILD-MAC.sh  macOS build script
│   ├── BUILD-LINUX.sh Linux build script
│   └── renderer/     Browser UI
├── mobile/           Android app (Capacitor)
│   └── BUILD-ANDROID.bat
├── search/           Orbiton Search Engine
│   └── index.html
├── website/          Landing + download pages
│   ├── index.html
│   └── download.html
├── index.html        GitHub Pages home
└── download.html     GitHub Pages download
```

## Build from source

### Desktop (Windows)
```
cd browser
npm install
npm run build:win
```

### Desktop (Linux)
```
cd browser
npm install
npm run build:linux
```

### Desktop (macOS)
```
cd browser
npm install
npm run build:mac
```

### Android APK
See `mobile/README.md`

## Features
- Chromium engine (full web compatibility)
- Multi-tab browsing
- Bookmarks bar
- Dark & light theme
- Built-in AdBlock, Dark Mode, Reader View extensions
- Chrome extension support (load from extensions folder)
- Orbiton Search integration
- Cross-platform: Windows, macOS, Linux, Android

## License
MIT — free forever.
