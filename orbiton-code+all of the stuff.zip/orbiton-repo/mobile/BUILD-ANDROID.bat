@echo off
title Orbiton Android Builder
cls
echo.
echo  ==========================================
echo   ORBITON Android Builder
echo  ==========================================
echo.
echo  Requirements:
echo    - Node.js (nodejs.org)
echo    - Android Studio (developer.android.com/studio)
echo    - Java JDK 17+
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (echo [ERROR] Node.js not found! & pause & exit /b 1)
echo [OK] Node.js found
echo.

echo [1/4] Installing Capacitor...
call npm install
if %errorlevel% neq 0 (echo [ERROR] npm install failed! & pause & exit /b 1)

echo [2/4] Adding Android platform...
call npx cap add android
if %errorlevel% neq 0 (echo [ERROR] cap add android failed! & pause & exit /b 1)

echo [3/4] Syncing web files...
call npx cap sync android

echo [4/4] Opening Android Studio...
echo  Build the APK in Android Studio:
echo  Build menu - Build Bundle/APK - Build APK
echo.
call npx cap open android

echo.
echo  APK will be at:
echo  android\app\build\outputs\apk\debug\app-debug.apk
echo.
pause
