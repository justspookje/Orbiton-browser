# Orbiton Mobile

Browser app for Android and iOS, built with Capacitor.

## Android APK

Requirements:
- Node.js
- Android Studio (free) — developer.android.com/studio
- Java JDK 17+

Steps:
1. Double-click BUILD-ANDROID.bat
2. Android Studio opens automatically
3. Go to: Build menu -> Build Bundle/APK -> Build APK
4. APK is at: android\app\build\outputs\apk\debug\app-debug.apk

Total time: ~10 minutes first run

---

## iOS IPA

Requirements:
- Mac with macOS
- Xcode (free from App Store)
- Apple Developer account ($99/year) — developer.apple.com

Steps:
1. Run: chmod +x BUILD-IOS.sh && ./BUILD-IOS.sh
2. Xcode opens automatically
3. Set your Apple Developer Team in Signing & Capabilities
4. Product menu -> Archive -> Distribute App
5. Choose Ad Hoc or App Store distribution

Note: Without a paid Apple Developer account, you can still
run the app on your own iPhone via TestFlight or direct install.
